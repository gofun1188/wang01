document.querySelector('.cta-btn').addEventListener('click', function() {
    alert('立即进入充值页面，享受幸运轮盘活动！');
  });
  